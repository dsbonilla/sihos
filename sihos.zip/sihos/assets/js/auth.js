document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('loginForm');
  const alertBox = document.getElementById('alertBox');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    alertBox.classList.add('d-none');

    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;

    try {
      const res = await fetch('api/auth/login.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
      const result = await res.json();

      if (!res.ok || !result.success) {
        showError(result.message || 'No se pudo iniciar sesión.');
        return;
      }

      window.location.href = 'pacientes.html';
    } catch (err) {
      showError('Error de conexión con el servidor.');
    }
  });

  function showError(msg) {
    alertBox.textContent = msg;
    alertBox.classList.remove('d-none');
  }
});
