// =====================================================
// SIHOS - Lógica CRUD de pacientes (assets/js/app.js)
// =====================================================

const API_PACIENTES = 'api/pacientes.php';
const API_CATALOGOS = 'api/catalogos.php';
const API_SESSION = 'api/session.php';
const API_LOGOUT = 'api/auth/logout.php';

// Estado en memoria
let municipiosData = [];   // [{id, departamento_id, nombre}]
let editandoId = null;     // null = modo creación, número = modo edición

// Elementos del DOM
const alertBox = document.getElementById('alertBox');
const sessionUser = document.getElementById('sessionUser');
const logoutBtn = document.getElementById('logoutBtn');

const form = document.getElementById('pacienteForm');
const formTitle = document.getElementById('formTitle');
const submitBtn = document.getElementById('submitBtn');
const cancelEditBtn = document.getElementById('cancelEditBtn');
const pacienteId = document.getElementById('pacienteId');

const tipoDocumentoSelect = document.getElementById('tipo_documento_id');
const generoSelect = document.getElementById('genero_id');
const departamentoSelect = document.getElementById('departamento_id');
const municipioSelect = document.getElementById('municipio_id');

const tableBody = document.getElementById('pacientesTableBody');

document.addEventListener('DOMContentLoaded', init);

async function init() {
    const ok = await checkSession();
    if (!ok) return;

    await cargarCatalogos();
    await cargarPacientes();

    departamentoSelect.addEventListener('change', () => {
        llenarMunicipios(departamentoSelect.value);
    });

    form.addEventListener('submit', onSubmitForm);
    cancelEditBtn.addEventListener('click', resetForm);
    logoutBtn.addEventListener('click', onLogout);
}

// ---------------------------------------------------------------
// Sesión
// ---------------------------------------------------------------
async function checkSession() {
    try {
        const res = await fetch(API_SESSION);
        const result = await res.json();

        if (!result.authenticated) {
            window.location.href = 'index.html';
            return false;
        }

        sessionUser.textContent = result.data.username;
        return true;
    } catch (err) {
        showAlert('No se pudo verificar la sesión.', 'danger');
        return false;
    }
}

async function onLogout() {
    try {
        await fetch(API_LOGOUT, { method: 'POST' });
    } finally {
        window.location.href = 'index.html';
    }
}

// ---------------------------------------------------------------
// Catálogos (selects)
// ---------------------------------------------------------------
async function cargarCatalogos() {
    try {
        const res = await fetch(API_CATALOGOS);
        const result = await res.json();

        if (!result.success) {
            showAlert('No se pudieron cargar los catálogos.', 'danger');
            return;
        }

        municipiosData = result.data.municipios;

        llenarSelect(tipoDocumentoSelect, result.data.tipos_documento, 'Seleccione...');
        llenarSelect(generoSelect, result.data.generos, 'Seleccione...');
        llenarSelect(departamentoSelect, result.data.departamentos, 'Seleccione...');

        municipioSelect.innerHTML = '<option value="">Seleccione un departamento primero</option>';
    } catch (err) {
        showAlert('Error de conexión al cargar catálogos.', 'danger');
    }
}

function llenarSelect(selectEl, items, placeholder) {
    selectEl.innerHTML = '';
    const opt0 = document.createElement('option');
    opt0.value = '';
    opt0.textContent = placeholder;
    selectEl.appendChild(opt0);

    items.forEach((item) => {
        const opt = document.createElement('option');
        opt.value = item.id;
        opt.textContent = item.nombre;
        selectEl.appendChild(opt);
    });
}

function llenarMunicipios(departamentoId, selectedMunicipioId = '') {
    municipioSelect.innerHTML = '';

    if (!departamentoId) {
        municipioSelect.innerHTML = '<option value="">Seleccione un departamento primero</option>';
        return;
    }

    const opt0 = document.createElement('option');
    opt0.value = '';
    opt0.textContent = 'Seleccione...';
    municipioSelect.appendChild(opt0);

    municipiosData
        .filter((m) => String(m.departamento_id) === String(departamentoId))
        .forEach((m) => {
            const opt = document.createElement('option');
            opt.value = m.id;
            opt.textContent = m.nombre;
            if (String(m.id) === String(selectedMunicipioId)) opt.selected = true;
            municipioSelect.appendChild(opt);
        });
}

// ---------------------------------------------------------------
// Listado de pacientes
// ---------------------------------------------------------------
async function cargarPacientes() {
    tableBody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">Cargando...</td></tr>';

    try {
        const res = await fetch(API_PACIENTES);
        const result = await res.json();

        if (!result.success) {
            tableBody.innerHTML = '<tr><td colspan="7" class="text-center text-danger">Error al cargar pacientes.</td></tr>';
            return;
        }

        renderTabla(result.data);
    } catch (err) {
        tableBody.innerHTML = '<tr><td colspan="7" class="text-center text-danger">Error de conexión.</td></tr>';
    }
}

function renderTabla(pacientes) {
    if (!pacientes.length) {
        tableBody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No hay pacientes registrados.</td></tr>';
        return;
    }

    tableBody.innerHTML = '';

    pacientes.forEach((p) => {
        const nombreCompleto = [p.nombre1, p.nombre2, p.apellido1, p.apellido2].filter(Boolean).join(' ');
        const ubicacion = `${p.municipio}, ${p.departamento}`;

        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${p.id}</td>
            <td>${p.tipo_documento}: ${escapeHtml(p.numero_documento)}</td>
            <td>${escapeHtml(nombreCompleto)}</td>
            <td>${escapeHtml(p.genero)}</td>
            <td>${escapeHtml(ubicacion)}</td>
            <td>${escapeHtml(p.correo)}</td>
            <td class="text-end">
                <button class="btn btn-sm btn-outline-primary me-1" data-action="editar" data-id="${p.id}">Editar</button>
                <button class="btn btn-sm btn-outline-danger" data-action="eliminar" data-id="${p.id}">Eliminar</button>
            </td>
        `;
        tableBody.appendChild(tr);
    });

    tableBody.querySelectorAll('[data-action="editar"]').forEach((btn) => {
        btn.addEventListener('click', () => editarPaciente(btn.dataset.id));
    });
    tableBody.querySelectorAll('[data-action="eliminar"]').forEach((btn) => {
        btn.addEventListener('click', () => eliminarPaciente(btn.dataset.id));
    });
}

// ---------------------------------------------------------------
// Crear / Actualizar
// ---------------------------------------------------------------
async function onSubmitForm(e) {
    e.preventDefault();

    const payload = {
        tipo_documento_id: tipoDocumentoSelect.value,
        numero_documento: document.getElementById('numero_documento').value.trim(),
        nombre1: document.getElementById('nombre1').value.trim(),
        nombre2: document.getElementById('nombre2').value.trim(),
        apellido1: document.getElementById('apellido1').value.trim(),
        apellido2: document.getElementById('apellido2').value.trim(),
        genero_id: generoSelect.value,
        departamento_id: departamentoSelect.value,
        municipio_id: municipioSelect.value,
        correo: document.getElementById('correo').value.trim(),
    };

    const esEdicion = editandoId !== null;
    const url = esEdicion ? `${API_PACIENTES}?id=${editandoId}` : API_PACIENTES;
    const method = esEdicion ? 'PUT' : 'POST';

    try {
        const res = await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        });
        const result = await res.json();

        if (!result.success) {
            if (result.errors) {
                const mensajes = Object.values(result.errors).join(' ');
                showAlert(mensajes, 'danger');
            } else {
                showAlert(result.message || 'Ocurrió un error.', 'danger');
            }
            return;
        }

        showAlert(result.message || (esEdicion ? 'Paciente actualizado correctamente.' : 'Paciente creado correctamente.'), 'success');
        resetForm();
        await cargarPacientes();
    } catch (err) {
        showAlert('Error de conexión con el servidor.', 'danger');
    }
}

async function editarPaciente(id) {
    try {
        const res = await fetch(`${API_PACIENTES}?id=${id}`);
        const result = await res.json();

        if (!result.success) {
            showAlert('No se pudo cargar el paciente.', 'danger');
            return;
        }

        const p = result.data;
        editandoId = p.id;
        pacienteId.value = p.id;

        tipoDocumentoSelect.value = p.tipo_documento_id;
        document.getElementById('numero_documento').value = p.numero_documento;
        document.getElementById('nombre1').value = p.nombre1;
        document.getElementById('nombre2').value = p.nombre2 || '';
        document.getElementById('apellido1').value = p.apellido1;
        document.getElementById('apellido2').value = p.apellido2 || '';
        generoSelect.value = p.genero_id;
        departamentoSelect.value = p.departamento_id;
        llenarMunicipios(p.departamento_id, p.municipio_id);
        document.getElementById('correo').value = p.correo;

        formTitle.textContent = `Editar paciente #${p.id}`;
        submitBtn.textContent = 'Actualizar paciente';
        cancelEditBtn.classList.remove('d-none');

        form.scrollIntoView({ behavior: 'smooth' });
    } catch (err) {
        showAlert('Error de conexión con el servidor.', 'danger');
    }
}

async function eliminarPaciente(id) {
    if (!confirm('¿Seguro que desea eliminar este paciente? Esta acción no se puede deshacer.')) {
        return;
    }

    try {
        const res = await fetch(`${API_PACIENTES}?id=${id}`, { method: 'DELETE' });
        const result = await res.json();

        if (!result.success) {
            showAlert(result.message || 'Error al eliminar paciente.', 'danger');
            return;
        }

        showAlert(result.message || 'Paciente eliminado correctamente.', 'success');

        if (editandoId === Number(id)) resetForm();
        await cargarPacientes();
    } catch (err) {
        showAlert('Error de conexión con el servidor.', 'danger');
    }
}

function resetForm() {
    editandoId = null;
    form.reset();
    pacienteId.value = '';
    municipioSelect.innerHTML = '<option value="">Seleccione un departamento primero</option>';

    formTitle.textContent = 'Nuevo paciente';
    submitBtn.textContent = 'Guardar paciente';
    cancelEditBtn.classList.add('d-none');
}

// ---------------------------------------------------------------
// Utilidades
// ---------------------------------------------------------------
function showAlert(message, type = 'info') {
    alertBox.className = `alert alert-${type}`;
    alertBox.textContent = message;
    alertBox.classList.remove('d-none');
    window.scrollTo({ top: 0, behavior: 'smooth' });

    setTimeout(() => alertBox.classList.add('d-none'), 5000);
}

function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}
