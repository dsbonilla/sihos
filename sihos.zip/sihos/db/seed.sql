-- =====================================================
-- SIHOS - Datos de prueba (seeders)
-- Ejecutar DESPUÉS de schema.sql
-- =====================================================

USE sihos_crud;

-- ---------- departamentos (5 registros) ----------
INSERT INTO departamentos (nombre) VALUES
('Antioquia'),
('Cundinamarca'),
('Valle del Cauca'),
('Santander'),
('Atlántico');

-- ---------- municipios (2 por cada departamento) ----------
INSERT INTO municipios (departamento_id, nombre) VALUES
(1, 'Medellín'),
(1, 'Envigado'),
(2, 'Bogotá'),
(2, 'Soacha'),
(3, 'Cali'),
(3, 'Palmira'),
(4, 'Bucaramanga'),
(4, 'Girón'),
(5, 'Barranquilla'),
(5, 'Soledad');

-- ---------- tipos_documento (2 registros) ----------
INSERT INTO tipos_documento (nombre) VALUES
('Cédula de Ciudadanía'),
('Tarjeta de Identidad');

-- ---------- genero ----------
INSERT INTO genero (nombre) VALUES
('Masculino'),
('Femenino'),
('Otro');

-- ---------- users: admin / 1234567890 (hash bcrypt) ----------
-- Usuario: admin   Contraseña: 1234567890
INSERT INTO users (username, password) VALUES
('admin', '$2b$10$pu1Rcpg7FZAQvUPWPbYaLOlf.g2SgJ6sVPTMd0j0agfd4DPua4lD6');

-- ---------- paciente (5 registros de prueba) ----------
INSERT INTO paciente
  (tipo_documento_id, numero_documento, nombre1, nombre2, apellido1, apellido2, genero_id, departamento_id, municipio_id, correo)
VALUES
(1, '1001234567', 'Juan', 'Carlos', 'Pérez', 'Gómez', 1, 1, 1, 'juan.perez@example.com'),
(1, '1002345678', 'María', 'Fernanda', 'López', 'Ruiz', 2, 2, 3, 'maria.lopez@example.com'),
(2, '1003456789', 'Andrés', NULL, 'Martínez', 'Torres', 1, 3, 5, 'andres.martinez@example.com'),
(1, '1004567890', 'Laura', 'Sofía', 'Ramírez', 'Díaz', 2, 4, 7, 'laura.ramirez@example.com'),
(1, '1005678901', 'Camila', NULL, 'Rodríguez', 'Suárez', 3, 5, 9, 'camila.rodriguez@example.com');
