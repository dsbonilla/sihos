-- =====================================================
-- SIHOS - Esquema de base de datos (migraciones)
-- Prueba técnica desarrollador
-- =====================================================

CREATE DATABASE IF NOT EXISTS sihos_crud
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE sihos_crud;

-- ---------- users (autenticación por sesión) ----------
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------- departamentos ----------
CREATE TABLE IF NOT EXISTS departamentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

-- ---------- municipios ----------
CREATE TABLE IF NOT EXISTS municipios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  departamento_id INT NOT NULL,
  nombre VARCHAR(100) NOT NULL,
  CONSTRAINT fk_municipio_departamento
    FOREIGN KEY (departamento_id) REFERENCES departamentos(id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------- tipos_documento ----------
CREATE TABLE IF NOT EXISTS tipos_documento (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(50) NOT NULL
) ENGINE=InnoDB;

-- ---------- genero ----------
CREATE TABLE IF NOT EXISTS genero (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(20) NOT NULL
) ENGINE=InnoDB;

-- ---------- paciente ----------
CREATE TABLE IF NOT EXISTS paciente (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tipo_documento_id INT NOT NULL,
  numero_documento VARCHAR(30) NOT NULL,
  nombre1 VARCHAR(50) NOT NULL,
  nombre2 VARCHAR(50) NULL,
  apellido1 VARCHAR(50) NOT NULL,
  apellido2 VARCHAR(50) NULL,
  genero_id INT NOT NULL,
  departamento_id INT NOT NULL,
  municipio_id INT NOT NULL,
  correo VARCHAR(100) NOT NULL,
  foto VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_paciente_documento (tipo_documento_id, numero_documento),
  CONSTRAINT fk_paciente_tipo_documento
    FOREIGN KEY (tipo_documento_id) REFERENCES tipos_documento(id),
  CONSTRAINT fk_paciente_genero
    FOREIGN KEY (genero_id) REFERENCES genero(id),
  CONSTRAINT fk_paciente_departamento
    FOREIGN KEY (departamento_id) REFERENCES departamentos(id),
  CONSTRAINT fk_paciente_municipio
    FOREIGN KEY (municipio_id) REFERENCES municipios(id)
) ENGINE=InnoDB;
