<?php

class Database
{
    private static $connection = null;

    // ---- Ajusta estos datos si tu XAMPP los tiene diferentes ----
    private static $host = '127.0.0.1';
    private static $dbName = 'sihos_crud';
    private static $user = 'root';
    private static $password = ''; // XAMPP por defecto no tiene password
    private static $port = 3306;
    // ---------------------------------------------------------------

    public static function getConnection()
    {
        if (self::$connection === null) {
            try {
                $dsn = sprintf(
                    'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
                    self::$host,
                    self::$port,
                    self::$dbName
                );

                self::$connection = new PDO($dsn, self::$user, self::$password, [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]);
            } catch (PDOException $e) {
                http_response_code(500);
                header('Content-Type: application/json');
                echo json_encode([
                    'success' => false,
                    'message' => 'Error de conexión a la base de datos: ' . $e->getMessage(),
                ]);
                exit;
            }
        }

        return self::$connection;
    }
}
