<?php
/**
 * Verifica que exista una sesión activa de usuario.
 * Incluir este archivo al inicio de cualquier endpoint protegido.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function require_auth(): void
{
    if (empty($_SESSION['user_id'])) {
        http_response_code(401);
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'No autorizado. Debe iniciar sesión.',
        ]);
        exit;
    }
}
