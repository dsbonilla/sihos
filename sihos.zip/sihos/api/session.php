<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');

if (!empty($_SESSION['user_id'])) {
    echo json_encode([
        'success' => true,
        'authenticated' => true,
        'data' => ['username' => $_SESSION['username']],
    ]);
} else {
    echo json_encode(['success' => true, 'authenticated' => false]);
}
