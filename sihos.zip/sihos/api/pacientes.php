<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../config/database.php';

require_auth();

$db = Database::getConnection();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        handleGet($db);
        break;
    case 'POST':
        handlePost($db);
        break;
    case 'PUT':
        handlePut($db);
        break;
    case 'DELETE':
        handleDelete($db);
        break;
    default:
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Método no permitido.']);
}

// ---------------------------------------------------------------
// GET /api/pacientes.php          -> lista todos
// GET /api/pacientes.php?id=1     -> obtiene uno
// ---------------------------------------------------------------
function handleGet(PDO $db): void
{
    $sql = "SELECT p.*,
                   td.nombre AS tipo_documento,
                   g.nombre  AS genero,
                   d.nombre  AS departamento,
                   m.nombre  AS municipio
            FROM paciente p
            JOIN tipos_documento td ON td.id = p.tipo_documento_id
            JOIN genero g           ON g.id  = p.genero_id
            JOIN departamentos d    ON d.id  = p.departamento_id
            JOIN municipios m       ON m.id  = p.municipio_id";

    if (!empty($_GET['id'])) {
        $stmt = $db->prepare($sql . ' WHERE p.id = :id');
        $stmt->execute(['id' => $_GET['id']]);
        $paciente = $stmt->fetch();

        if (!$paciente) {
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'Paciente no encontrado.']);
            return;
        }

        echo json_encode(['success' => true, 'data' => $paciente]);
        return;
    }

    $stmt = $db->query($sql . ' ORDER BY p.id DESC');
    echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
}

// ---------------------------------------------------------------
// POST /api/pacientes.php  -> crea un paciente
// ---------------------------------------------------------------
function handlePost(PDO $db): void
{
    $input = json_decode(file_get_contents('php://input'), true) ?? [];

    $errors = validatePaciente($input);
    if ($errors) {
        http_response_code(422);
        echo json_encode(['success' => false, 'errors' => $errors]);
        return;
    }

    $sql = "INSERT INTO paciente
              (tipo_documento_id, numero_documento, nombre1, nombre2, apellido1, apellido2,
               genero_id, departamento_id, municipio_id, correo)
            VALUES
              (:tipo_documento_id, :numero_documento, :nombre1, :nombre2, :apellido1, :apellido2,
               :genero_id, :departamento_id, :municipio_id, :correo)";

    try {
        $stmt = $db->prepare($sql);
        $stmt->execute(paramsFromInput($input));

        echo json_encode([
            'success' => true,
            'message' => 'Paciente creado correctamente.',
            'data' => ['id' => $db->lastInsertId()],
        ]);
    } catch (PDOException $e) {
        handleDbError($e);
    }
}

// ---------------------------------------------------------------
// PUT /api/pacientes.php?id=1  -> actualiza un paciente
// ---------------------------------------------------------------
function handlePut(PDO $db): void
{
    $id = $_GET['id'] ?? null;
    if (!$id) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Falta el parámetro id.']);
        return;
    }

    $input = json_decode(file_get_contents('php://input'), true) ?? [];

    $errors = validatePaciente($input);
    if ($errors) {
        http_response_code(422);
        echo json_encode(['success' => false, 'errors' => $errors]);
        return;
    }

    $sql = "UPDATE paciente SET
              tipo_documento_id = :tipo_documento_id,
              numero_documento  = :numero_documento,
              nombre1           = :nombre1,
              nombre2           = :nombre2,
              apellido1         = :apellido1,
              apellido2         = :apellido2,
              genero_id         = :genero_id,
              departamento_id   = :departamento_id,
              municipio_id      = :municipio_id,
              correo            = :correo
            WHERE id = :id";

    try {
        $params = paramsFromInput($input);
        $params['id'] = $id;

        $stmt = $db->prepare($sql);
        $stmt->execute($params);

        if ($stmt->rowCount() === 0) {
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'Paciente no encontrado o sin cambios.']);
            return;
        }

        echo json_encode(['success' => true, 'message' => 'Paciente actualizado correctamente.']);
    } catch (PDOException $e) {
        handleDbError($e);
    }
}

// ---------------------------------------------------------------
// DELETE /api/pacientes.php?id=1  -> elimina un paciente
// ---------------------------------------------------------------
function handleDelete(PDO $db): void
{
    $id = $_GET['id'] ?? null;
    if (!$id) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Falta el parámetro id.']);
        return;
    }

    $stmt = $db->prepare('DELETE FROM paciente WHERE id = :id');
    $stmt->execute(['id' => $id]);

    if ($stmt->rowCount() === 0) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Paciente no encontrado.']);
        return;
    }

    echo json_encode(['success' => true, 'message' => 'Paciente eliminado correctamente.']);
}

// ---------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------
function validatePaciente(array $input): array
{
    $errors = [];

    $required = [
        'tipo_documento_id', 'numero_documento', 'nombre1', 'apellido1',
        'genero_id', 'departamento_id', 'municipio_id', 'correo',
    ];

    foreach ($required as $field) {
        if (empty($input[$field]) && $input[$field] !== '0') {
            $errors[$field] = "El campo {$field} es obligatorio.";
        }
    }

    if (!empty($input['correo']) && !filter_var($input['correo'], FILTER_VALIDATE_EMAIL)) {
        $errors['correo'] = 'El correo electrónico no tiene un formato válido.';
    }

    foreach (['tipo_documento_id', 'genero_id', 'departamento_id', 'municipio_id'] as $field) {
        if (!empty($input[$field]) && !ctype_digit((string)$input[$field])) {
            $errors[$field] = "El campo {$field} debe ser numérico.";
        }
    }

    return $errors;
}

function paramsFromInput(array $input): array
{
    return [
        'tipo_documento_id' => $input['tipo_documento_id'],
        'numero_documento'  => trim($input['numero_documento']),
        'nombre1'           => trim($input['nombre1']),
        'nombre2'           => trim($input['nombre2'] ?? '') ?: null,
        'apellido1'         => trim($input['apellido1']),
        'apellido2'         => trim($input['apellido2'] ?? '') ?: null,
        'genero_id'         => $input['genero_id'],
        'departamento_id'   => $input['departamento_id'],
        'municipio_id'      => $input['municipio_id'],
        'correo'            => trim($input['correo']),
    ];
}

function handleDbError(PDOException $e): void
{
    // Error 1062 = entrada duplicada (unique key)
    if ((int)$e->errorInfo[1] === 1062) {
        http_response_code(409);
        echo json_encode([
            'success' => false,
            'message' => 'Ya existe un paciente con ese tipo y número de documento.',
        ]);
        return;
    }

    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error de base de datos: ' . $e->getMessage()]);
}
