<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../config/database.php';

require_auth();

$db = Database::getConnection();

$departamentos   = $db->query('SELECT id, nombre FROM departamentos ORDER BY nombre')->fetchAll();
$municipios      = $db->query('SELECT id, departamento_id, nombre FROM municipios ORDER BY nombre')->fetchAll();
$tiposDocumento  = $db->query('SELECT id, nombre FROM tipos_documento ORDER BY nombre')->fetchAll();
$generos         = $db->query('SELECT id, nombre FROM genero ORDER BY nombre')->fetchAll();

echo json_encode([
    'success' => true,
    'data' => [
        'departamentos'    => $departamentos,
        'municipios'       => $municipios,
        'tipos_documento'  => $tiposDocumento,
        'generos'          => $generos,
    ],
]);
